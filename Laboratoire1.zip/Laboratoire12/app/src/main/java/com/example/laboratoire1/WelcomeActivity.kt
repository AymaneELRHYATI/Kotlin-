package com.example.laboratoire1

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class WelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
    }

    fun onStaticHostButtonClick(view: View) {
        val intent = Intent(this, StaticHostActivity::class.java)
        startActivity(intent)
    }

    fun onDynamicHostButtonClick(view: View) {
        // Assuming DynamicHostActivity is the actual name of your dynamic host activity
        val intent = Intent(this, DynamicHostActivity::class.java)
        startActivity(intent)
    }
}
