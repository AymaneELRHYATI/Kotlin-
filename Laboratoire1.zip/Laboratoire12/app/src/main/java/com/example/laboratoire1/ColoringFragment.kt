package com.example.laboratoire1

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import kotlin.random.Random

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class ColoringFragment : Fragment() {
    private lateinit var btnReplace: Button

    interface OnColoringFragmentInteractionListener {
        fun onSendColorFragmentInteraction(nextInt: Int)
        fun onChangeFragment()
    }

    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    private lateinit var mListener: OnColoringFragmentInteractionListener
    private val TAG = ColoringFragment::class.java.canonicalName

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "${javaClass.simpleName}: entered ${object {}.javaClass.enclosingMethod.name}")
        try {
            mListener = context as OnColoringFragmentInteractionListener
        } catch (e: ClassCastException) {
            throw ClassCastException("$context must implement OnColoringFragmentInteractionListener")
        }
    }

    fun enableReplaceFragmentButton() {
        if (::btnReplace.isInitialized) {
            btnReplace.isEnabled = true
            btnReplace.setOnClickListener {
                mListener.onChangeFragment()
            }
        } else {
            Log.e(TAG, "btnReplace is not initialized")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_coloring, container, false)

        view.setOnClickListener {
            mListener.onSendColorFragmentInteraction(Random.nextInt())
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btnReplace = view.findViewById(R.id.button)
        enableReplaceFragmentButton()
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ColoringFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
