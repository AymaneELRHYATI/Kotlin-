package com.example.laboratoire1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DynamicHostActivity : AppCompatActivity(),ColoringFragment.OnColoringFragmentInteractionListener {
    private lateinit var dynamicColoredFragment: ColoredFragment
    private lateinit var dynamicColoringFragment: ColoringFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dynamic_host)
        dynamicColoringFragment = ColoringFragment.newInstance("", "")
        dynamicColoredFragment = ColoredFragment.newInstance("", "")
        val  fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.add(R.id.topLinearLayout, dynamicColoringFragment)
        fragmentTransaction.add(R.id.bottomLinearLayout, dynamicColoredFragment)
        fragmentTransaction.commit()
        enableReplaceFragmentButton()

    }
    private fun enableReplaceFragmentButton() {
        val replaceFragmentButton: Button = findViewById(R.id.button)

        replaceFragmentButton.setOnClickListener {
            onChangeFragment()
        }
    }
    override fun onSendColorFragmentInteraction(color: Int) {
        dynamicColoredFragment.setLayoutBackgroundColor(color)
    }
    override fun onChangeFragment() {
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        val fragment = ReplacingFragment()

        // Vérifier si le fragment est déjà ajouté
        val existingFragment = supportFragmentManager.findFragmentByTag(ReplacingFragment::class.java.simpleName)
        if (existingFragment == null) {
            // Ajouter le fragment uniquement s'il n'existe pas déjà
            fragmentTransaction.replace(R.id.topLinearLayout, fragment, ReplacingFragment::class.java.simpleName)
            fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()
        }
    }
    override fun onResume() { super.onResume()
        dynamicColoringFragment.enableReplaceFragmentButton()
    }
}