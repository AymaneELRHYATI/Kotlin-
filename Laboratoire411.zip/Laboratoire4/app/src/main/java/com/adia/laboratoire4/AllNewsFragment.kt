package com.adia.laboratoire4

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import androidx.recyclerview.widget.RecyclerView
import com.adia.laboratoire4.R

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [AllNewsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AllNewsFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var newsAdapter: NewsAdapter
   // private val newsViewModel: NewsViewModel by navGraphViewModels(R.id.news_nav_graph)
    private val viewModel: NewsViewModel by navGraphViewModels(R.id.news_nav_graph)
 override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_all_news, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        newsAdapter = NewsAdapter()

        // Find RecyclerView in the layout and set the adapter
        val rvSearchingNews: RecyclerView = view.findViewById(R.id.rvSearchingNews)
        val question=view.findViewById<EditText>(R.id.editText_question)
        val buttonSearch =view.findViewById<Button>(R.id.search)

        buttonSearch.setOnClickListener {
           // viewModel.question = question.text.toString()
            viewModel.ask(question.text.toString())
            rvSearchingNews.adapter = newsAdapter
            viewModel.searchingNews.observe(viewLifecycleOwner, Observer { newsResponse ->
                // Log to check if this block is executed
                Log.d("SearchFragment", "Observer called with data: $newsResponse")

                // Update your UI or adapter here with newsResponse.articles
                newsAdapter.setArticles(newsResponse.articles)

            })
        }
        newsAdapter.setOnItemClickListener {
            Log.i("Labo4", "You have clicked on me!!")
            val bundle = Bundle().apply {
                putSerializable("article", it) }
            findNavController().navigate( R.id.action_allNewsFragment_to_articleFragment, bundle
            )
        }


        rvSearchingNews.adapter = newsAdapter

        viewModel.searchingNews.observe(viewLifecycleOwner, Observer { newsResponse ->

            newsAdapter.setArticles(newsResponse.articles)
        })
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment AllNewsFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            AllNewsFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}