package com.adia.laboratoire4

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.adia.laboratoire4.repository.NewsRepository

class NewsViewModelProviderFactory(
    private val newsRepository: NewsRepository,
    private val application: Application
): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return if(modelClass.isAssignableFrom(NewsViewModel::class.java)){
            NewsViewModel(newsRepository,application) as T
        }else{
            throw IllegalArgumentException("Unknown ViewModel class")
        } }
}