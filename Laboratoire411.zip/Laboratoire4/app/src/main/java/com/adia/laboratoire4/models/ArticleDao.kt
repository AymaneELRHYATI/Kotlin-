package com.adia.laboratoire4.models

import androidx.lifecycle.LiveData
import androidx.room.*


    @Dao
    interface ArticleDao {
        @Query("SELECT * from saved_news ")
        fun getArticles(): LiveData<List<ArticleEntity>>
        @Query("SELECT * FROM saved_news WHERE id=(:id)")
        fun getStudent(id: Int): LiveData<ArticleEntity?>
        @Insert(onConflict = OnConflictStrategy.IGNORE)
        fun insert(Article: ArticleEntity)
        @Update
        fun updateArticle(student: ArticleEntity)
        @Delete
        fun deleteArticle(student: ArticleEntity)

        @Query("DELETE FROM saved_news")
        fun deleteAll()
    }