package com.adia.laboratoire4.models

import androidx.lifecycle.LiveData

class Article_Repository (private val articleDao: ArticleDao) {


        // Room execute toutes les requêtes dans un thread séparé.
// Observed LiveData will notify the observer when the data has changed.
        val allSavedNews: LiveData<List<ArticleEntity>> = articleDao.getArticles()
        suspend fun insert(Article: ArticleEntity){
            articleDao.insert(Article)
        }
    suspend fun  deleteFromDb(Article: ArticleEntity){
        articleDao.deleteArticle(Article)

    }


}