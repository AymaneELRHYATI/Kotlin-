package com.adia.laboratoire4.models

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase



    @Database(entities = arrayOf(ArticleEntity::class), version = 1, exportSchema = false)
    abstract class  ArticleRoomDataBase: RoomDatabase() {
        abstract fun articleDao(): ArticleDao
        companion object{
            //Singleton to prevent multiple instances of database openint at the same time
            @Volatile
            private var INSTANCE: ArticleRoomDataBase? = null
            fun getDatabase(context: Context): ArticleRoomDataBase {
                val tempInstance = INSTANCE
                if(tempInstance != null)
                {
                    return tempInstance
                }
                INSTANCE = Room.databaseBuilder( context.applicationContext, ArticleRoomDataBase::class.java, "saved_articles_database"
                ).build()
                return INSTANCE as ArticleRoomDataBase
            }
        }
    }