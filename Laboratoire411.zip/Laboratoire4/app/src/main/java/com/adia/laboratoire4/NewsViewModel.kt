package com.adia.laboratoire4

import android.app.Application
import androidx.lifecycle.*
import com.adia.laboratoire4.models.ArticleRoomDataBase
import com.adia.laboratoire4.models.ArticleEntity
import com.adia.laboratoire4.models.Article_Repository
import com.adia.laboratoire4.models.NewsResponse
import com.adia.laboratoire4.repository.NewsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NewsViewModel(
    private val newsRepository:     NewsRepository,
    application: Application
) : AndroidViewModel(application) {
    val allSavedNews: LiveData<List<ArticleEntity>>

    private val repository: Article_Repository
    val breakingNews: MutableLiveData<NewsResponse> = MutableLiveData()
    val searchingNews: MutableLiveData<NewsResponse> = MutableLiveData()
    var question:String= "data"
    init {
        getBreakingNews("us")
        getSearchingNews(question)


        val articleDao = ArticleRoomDataBase.getDatabase(application).articleDao()
        repository = Article_Repository(articleDao)
        allSavedNews = repository.allSavedNews
    }

    private fun getBreakingNews(countryCode: String) = viewModelScope.launch {
        try {
            val response = newsRepository.getBreakingNews(countryCode)
            breakingNews.postValue(response.body())
        }catch (e: Exception){
        }
    }
  public fun ask(q: String){
      question=q.toString()
      getSearchingNews(question)
  }
    private fun getSearchingNews(question: String) = viewModelScope.launch {
        try {
            val response = newsRepository.getSearchNews(question)
            searchingNews.postValue(response.body())
        }catch (e: Exception){
        }
    }


    fun insert(article: ArticleEntity) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(article)
        }

    fun deleteFromDb(article: ArticleEntity) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFromDb(article)
        }
}



