package com.adia.laboratoire4

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.adia.laboratoire4.models.Article
import com.adia.laboratoire4.models.ArticleEntity
import com.bumptech.glide.Glide
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.security.AccessController.getContext


class NewsAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var selectedNewsIndex: Int = RecyclerView.NO_POSITION
    private var articles: List<Article> = emptyList()
    private var savedArticles: List<ArticleEntity> = emptyList()
    private lateinit var onItemClickListener: ((Article) -> Unit)
    private lateinit var onItemClickListener1: ((ArticleEntity) -> Unit)
    inner class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCoverImage: ImageView = itemView.findViewById(R.id.ivCoverImage)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)

        init {
            itemView.setOnClickListener {
                selectedNewsIndex = adapterPosition
                onItemClickListener(articles[adapterPosition])
            }
        }
    }

    inner class SavedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCoverImagea: ImageView = itemView.findViewById(R.id.ivCoverImage)
        val tvTitlea: TextView = itemView.findViewById(R.id.tvTitle)
        init {
            itemView.setOnClickListener {
                selectedNewsIndex = adapterPosition
            }
            itemView.findViewById<FloatingActionButton>(R.id.faba).setOnClickListener{
                onItemClickListener1(savedArticles[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        return when (viewType) {
            NEWS_ITEM_VIEW_TYPE -> {
                val view = inflater.inflate(R.layout.news_item, parent, false)
                NewsViewHolder(view)
            }
            SAVED_ITEM_VIEW_TYPE -> {
                val view = inflater.inflate(R.layout.saved_item, parent, false)
                SavedViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid viewType: $viewType")
        }
    }

    override fun getItemCount(): Int =  savedArticles.size+articles.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is NewsViewHolder) {
            val article = articles[position]
            holder.tvTitle.text = article.title
            Glide.with(holder.itemView).load(article.urlToImage).into(holder.ivCoverImage)
        } else if (holder is SavedViewHolder) {
            val article = savedArticles[position]
            holder.tvTitlea.text = article.title
            Glide.with(holder.itemView).load(article.urlToImage).into(holder.ivCoverImagea)

            // Load image and handle click for saved articles
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (position < articles.size) {
            NEWS_ITEM_VIEW_TYPE
        } else {
            SAVED_ITEM_VIEW_TYPE
        }
    }

    fun setArticles(articles: List<Article>) {
        this.articles = articles
        notifyDataSetChanged()
    }
    fun getSelectedNews():Int{
        return   selectedNewsIndex
    }
    fun getSelecteditem():ArticleEntity{
        return   savedArticles[selectedNewsIndex]
    }

    fun setSaved(savedArticles: List<ArticleEntity>) {
        this.savedArticles = savedArticles
        notifyDataSetChanged()
    }

    fun setOnItemClickListener(listener: (Article) -> Unit) {
        onItemClickListener = listener
    }
    fun setOnItemClickListener1(listener: (ArticleEntity) -> Unit) {
        onItemClickListener1 = listener
    }

    companion object {
        private const val NEWS_ITEM_VIEW_TYPE = 1
        private const val SAVED_ITEM_VIEW_TYPE = 2
    }
}