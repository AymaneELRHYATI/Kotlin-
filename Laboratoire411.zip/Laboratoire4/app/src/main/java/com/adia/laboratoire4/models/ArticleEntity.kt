package com.adia.laboratoire4.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_news")
data class ArticleEntity(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="id")
    val id:Int,

    val author: String,

    val content: String,

    val description: String,

    val publishedAt: String,

    val source: String,

    val title: String,

    val url: String,

    val urlToImage: String


)





