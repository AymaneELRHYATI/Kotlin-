package com.example.roomstudent

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.*


class MainActivity : AppCompatActivity() {
    private val newStudentActivityRequestCode = 1
    private val studentViewModel: StudentViewModel by lazy {
        ViewModelProvider(this,
            StudentViewModelFactory(application)).get(StudentViewModel::class.java)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val adapter = StudentListAdapter(this)
        val recyclerView: RecyclerView = findViewById(R.id.recyclerview)

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        studentViewModel.allStudents.observe(this, Observer { students ->
            // Update the cached copy of the students in the adapter.
            students?.let { adapter.setStudents(it) }
        })
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            val intent = Intent(this@MainActivity, NewStudentActivity::class.java)
            startActivityForResult(intent, newStudentActivityRequestCode)
        }


    }
    @Entity(tableName = "student_table")
    data class Student(
        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name="id")
        val id:Int,
        @ColumnInfo(name = "firstName")
        val firstName: String,
        @ColumnInfo(name = "lastName")
        val lastName: String,
        @ColumnInfo(name = "phoneNumber")
        val phoneNumber: String,
        @ColumnInfo(name = "email")
        val email: String
    )

    @Dao
    interface StudentDao {
        @Query("SELECT * from student_table ORDER BY firstName ASC")
        suspend fun getStudents(): LiveData<List<Student>>
        @Query("SELECT * FROM student_table WHERE id=(:id)")
        suspend fun getStudent(id: Int): LiveData<Student?>
        @Insert(onConflict = OnConflictStrategy.IGNORE)
        suspend fun insert(student: Student)
        @Update
        suspend fun updateStudent(student: Student)
        @Query("DELETE FROM student_table")
        suspend fun deleteAll()
        @Query("SELECT * FROM student_table WHERE firstName LIKE :name OR lastName LIKE :name ORDER BY firstName ASC")
        suspend fun getStudentsByName(name: String): LiveData<List<Student>>
        @Delete
        suspend fun deleteStudent(student: Student)
    }

    @Database(entities = arrayOf(Student::class), version = 1, exportSchema = false)
    abstract class StudentRoomDatabase: RoomDatabase() {
        abstract fun studentDao(): StudentDao
        companion object{
            //Singleton to prevent multiple instances of database openint at the same time
            @Volatile
            private var INSTANCE: StudentRoomDatabase? = null
            fun getDatabase(context: Context): StudentRoomDatabase {
                val tempInstance = INSTANCE
                if(tempInstance != null)
                {
                    return tempInstance
                }
                INSTANCE = Room.databaseBuilder(
                    context.applicationContext,
                    StudentRoomDatabase::class.java,
                    "student_database"
                ).build()
                return INSTANCE as StudentRoomDatabase
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, intentData:
    Intent?) {
        super.onActivityResult(requestCode, resultCode, intentData)
        if (requestCode == newStudentActivityRequestCode && resultCode ==
            RESULT_OK) {
            intentData?.let { data ->
                val student = Student(
                    0,
                    data.getStringExtra(NewStudentActivity.EXTRA_FIRSTNAME) as
                            String,
                    data.getStringExtra(NewStudentActivity.EXTRA_LASTNAME) as
                            String,
                    data.getStringExtra(NewStudentActivity.EXTRA_PHONENUMBER) as
                            String,
                    data.getStringExtra(NewStudentActivity.EXTRA_EMAIL) as String
                )
                studentViewModel.insert(student)
            }
        } else {
            Toast.makeText(
                applicationContext,
                R.string.empty_not_saved,
                Toast.LENGTH_LONG
            ).show()
        }
    }
}