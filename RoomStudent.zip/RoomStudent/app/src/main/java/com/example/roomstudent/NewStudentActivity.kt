package com.example.roomstudent

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class NewStudentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_student)

        // Assuming you have these views in your XML layout file
        // Make sure to replace the IDs with the actual IDs from your layout file
        val buttonSave = findViewById<Button>(R.id.buttonSave)
        val editFirstNameView = findViewById<EditText>(R.id.editFirstNameView)
        val editLastNameView = findViewById<EditText>(R.id.editLastNameView)
        val editPhoneNumberView = findViewById<EditText>(R.id.editPhoneNumberView)
        val editEmailView = findViewById<EditText>(R.id.editEmailView)

        buttonSave.setOnClickListener {
            val replyIntent = Intent()
            if (TextUtils.isEmpty(editFirstNameView.text)) {
                setResult(Activity.RESULT_CANCELED, replyIntent)
            } else {
                val firstName = editFirstNameView.text.toString()
                replyIntent.putExtra(EXTRA_FIRSTNAME, firstName)
                val lastName = editLastNameView.text.toString()
                replyIntent.putExtra(EXTRA_LASTNAME, lastName)
                val phoneNumber = editPhoneNumberView.text.toString()
                replyIntent.putExtra(EXTRA_PHONENUMBER, phoneNumber)
                val email = editEmailView.text.toString()
                replyIntent.putExtra(EXTRA_EMAIL, email)
                setResult(Activity.RESULT_OK, replyIntent)
            }
            finish()
        }
    }

    companion object {
        const val EXTRA_FIRSTNAME = "FIRSTNAME"
        const val EXTRA_LASTNAME = "LASTNAME"
        const val EXTRA_PHONENUMBER = "PHONENUMBER"
        const val EXTRA_EMAIL = "EMAIL"
    }
}
