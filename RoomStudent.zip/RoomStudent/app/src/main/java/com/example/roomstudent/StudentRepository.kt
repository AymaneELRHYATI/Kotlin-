package com.example.roomstudent

import androidx.lifecycle.LiveData

class StudentRepository(private val studentDao: MainActivity.StudentDao) {
    val allStudents: LiveData<List<MainActivity.Student>> = studentDao.getStudents()

    suspend fun insert(student: MainActivity.Student) {
        studentDao.insert(student)
    }

    suspend fun updateStudent(student: MainActivity.Student) {
        studentDao.updateStudent(student)
    }

    suspend fun deleteStudent(student: MainActivity.Student) {
        studentDao.deleteStudent(student)
    }

    fun getStudentsByName(name: String): LiveData<List<MainActivity.Student>> {
        return studentDao.getStudentsByName(name)
    }
}

