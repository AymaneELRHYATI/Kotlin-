package com.adia.laboratoire4

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adia.laboratoire4.models.NewsResponse
import com.adia.laboratoire4.repository.NewsRepository
import kotlinx.coroutines.launch

class NewsViewModel(
    private val newsRepository:     NewsRepository
) : ViewModel() {
    val breakingNews: MutableLiveData<NewsResponse> = MutableLiveData()
    val searchingNews: MutableLiveData<NewsResponse> = MutableLiveData()
    init {
        getBreakingNews("ca")
        getSearchingNews("technology")
    }
    private fun getBreakingNews(countryCode: String) = viewModelScope.launch {
        try {
            val response = newsRepository.getBreakingNews(countryCode)
            breakingNews.postValue(response.body())
        }catch (e: Exception){
        }
    }

    private fun getSearchingNews(question: String) = viewModelScope.launch {
        try {
            val response = newsRepository.getSearchNews(question)
            searchingNews.postValue(response.body())
        }catch (e: Exception){
        }
    }


    }