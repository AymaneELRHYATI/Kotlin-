package com.adia.laboratoire4

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment.Companion.findNavController
import androidx.navigation.fragment.findNavController

import androidx.navigation.navGraphViewModels
import androidx.recyclerview.widget.RecyclerView
import com.adia.laboratoire4.R
import com.adia.laboratoire4.repository.NewsRepository

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [BreakingNewsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */class BreakingNewsFragment : Fragment(R.layout.fragment_breaking_news) {
   private lateinit var newsAdapter: NewsAdapter
    private val newsViewModel: NewsViewModel by navGraphViewModels(R.id.news_nav_graph)
    private val viewModel: NewsViewModel by navGraphViewModels(R.id.news_nav_graph)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        newsAdapter = NewsAdapter()

        // Find RecyclerView in the layout and set the adapter
        val rvBreakingNews: RecyclerView = view.findViewById(R.id.rvBreakingNews)
        rvBreakingNews.adapter = newsAdapter

        viewModel.breakingNews.observe(viewLifecycleOwner, Observer { newsResponse ->
            newsAdapter.setArticles(newsResponse.articles)
        })
        newsAdapter.setOnItemClickListener {
            Log.i("Labo10", "You have clicked on me!!")
            val bundle = Bundle().apply {
            putSerializable("article", it) }
            findNavController().navigate( R.id.action_breakingNewsFragment_to_articleFragment, bundle
            )
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            BreakingNewsFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
